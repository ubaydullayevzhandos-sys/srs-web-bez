
import sqlite3
import hashlib
import secrets
import sys
import getpass
from datetime import datetime, timedelta
from http.server import HTTPServer, BaseHTTPRequestHandler
from http.cookies import SimpleCookie
from urllib.parse import parse_qs, urlparse
from html import escape

DB = "authlab.db"


def connect():
    return sqlite3.connect(DB)


def init():
    db = connect()

    db.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        salt TEXT,
        role TEXT CHECK(role IN ('student','teacher'))
    )
    """)

    db.execute("""
    CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id INTEGER,
        content TEXT
    )
    """)

    db.execute("""
    CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        user_id INTEGER,
        csrf TEXT,
        created TEXT,
        last_activity TEXT
    )
    """)

    db.commit()
    db.close()
    print("Database initialized")


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode(),
        salt.encode(),
        600000
    ).hex()


def add_user(username, password, role):
    if role not in ("student", "teacher"):
        print("Invalid role")
        return

    salt = secrets.token_hex(16)
    hashed = hash_password(password, salt)

    db = connect()
    try:
        db.execute(
            "INSERT INTO users(username,password,salt,role) VALUES(?,?,?,?)",
            (username, hashed, salt, role)
        )
        db.commit()
        print("User created successfully")
    except sqlite3.IntegrityError:
        print("Username already exists")
    finally:
        db.close()


class AuthHandler(BaseHTTPRequestHandler):

    def send_page(self, content, status=200, cookie=None):
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Security-Policy", "default-src 'self'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")

        if cookie:
            self.send_header("Set-Cookie", cookie)

        self.end_headers()
        self.wfile.write(content.encode("utf-8"))

    def get_user(self):
        cookies = SimpleCookie()
        cookies.load(self.headers.get("Cookie", ""))

        if "session" not in cookies:
            return None

        token = cookies["session"].value
        token_hash = hashlib.sha256(token.encode()).hexdigest()

        db = connect()

        row = db.execute("""
            SELECT users.id, users.username, users.role,
                   sessions.csrf, sessions.created,
                   sessions.last_activity
            FROM sessions
            JOIN users ON users.id = sessions.user_id
            WHERE sessions.token = ?
        """, (token_hash,)).fetchone()

        if not row:
            db.close()
            return None

        now = datetime.now()
        created = datetime.fromisoformat(row[4])
        last = datetime.fromisoformat(row[5])

        if (now - created > timedelta(hours=4) or
                now - last > timedelta(minutes=20)):
            db.execute(
                "DELETE FROM sessions WHERE token = ?",
                (token_hash,)
            )
            db.commit()
            db.close()
            return None

        db.execute(
            "UPDATE sessions SET last_activity = ? WHERE token = ?",
            (now.isoformat(), token_hash)
        )
        db.commit()
        db.close()

        return {
            "id": row[0],
            "username": row[1],
            "role": row[2],
            "csrf": row[3]
        }

    def do_GET(self):
        path = urlparse(self.path).path
        user = self.get_user()

        if path == "/login":
            self.send_page("""
            <h2>AuthLab Login</h2>
            <form method="POST" action="/login">
                <input name="username" placeholder="Username" required>
                <br><br>
                <input name="password" type="password"
                placeholder="Password" required>
                <br><br>
                <button type="submit">Login</button>
            </form>
            """)
            return

        if not user:
            self.send_response(303)
            self.send_header("Location", "/login")
            self.end_headers()
            return

        if path == "/dashboard":
            self.send_page(f"""
            <h2>Welcome, {escape(user['username'])}</h2>
            <p>Role: {escape(user['role'])}</p>

            <form method="POST" action="/note">
                <input type="hidden" name="csrf"
                value="{escape(user['csrf'])}">
                <input name="content" placeholder="Your note" required>
                <button type="submit">Create note</button>
            </form>

            <p><a href="/notes">My notes</a></p>
            <p><a href="/admin/users">Admin users</a></p>

            <form method="POST" action="/logout">
                <input type="hidden" name="csrf"
                value="{escape(user['csrf'])}">
                <button type="submit">Logout</button>
            </form>
            """)
            return

        if path == "/notes":
            db = connect()
            rows = db.execute(
                "SELECT id, content FROM notes WHERE owner_id = ?",
                (user["id"],)
            ).fetchall()
            db.close()

            content = "<h2>My notes</h2>"

            for note in rows:
                content += (
                    f"<p><a href='/notes/{note[0]}'>"
                    f"Note {note[0]}</a>: {escape(note[1])}</p>"
                )

            self.send_page(content)
            return

        if path == "/admin/users":
            if user["role"] != "teacher":
                self.send_page("Forbidden", 403)
                return

            db = connect()
            rows = db.execute(
                "SELECT username, role FROM users"
            ).fetchall()
            db.close()

            content = "<h2>Users</h2>"

            for username, role in rows:
                content += (
                    f"<p>{escape(username)} - {escape(role)}</p>"
                )

            self.send_page(content)
            return

        if path.startswith("/notes/"):
            try:
                note_id = int(path.split("/")[-1])
            except ValueError:
                self.send_page("Not found", 404)
                return

            db = connect()
            note = db.execute(
                "SELECT content FROM notes WHERE id=? AND owner_id=?",
                (note_id, user["id"])
            ).fetchone()
            db.close()

            if note is None:
                self.send_page("Not found", 404)
            else:
                self.send_page(escape(note[0]))
            return

        self.send_page("Not found", 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        data = parse_qs(self.rfile.read(length).decode("utf-8"))
        path = urlparse(self.path).path

        # Login
        if path == "/login":
            username = data.get("username", [""])[0]
            password = data.get("password", [""])[0]

            db = connect()
            row = db.execute(
                "SELECT id, password, salt FROM users WHERE username=?",
                (username,)
            ).fetchone()

            if row is None or hash_password(password, row[2]) != row[1]:
                db.close()
                self.send_page("Invalid username or password", 401)
                return

            token = secrets.token_hex(32)
            csrf = secrets.token_hex(32)
            now = datetime.now().isoformat()

            token_hash = hashlib.sha256(token.encode()).hexdigest()

            db.execute("""
                INSERT INTO sessions
                (token, user_id, csrf, created, last_activity)
                VALUES (?, ?, ?, ?, ?)
            """, (token_hash, row[0], csrf, now, now))

            db.commit()
            db.close()

            self.send_response(303)
            self.send_header(
                "Set-Cookie",
                f"session={token}; HttpOnly; SameSite=Lax; Path=/"
            )
            self.send_header("Location", "/dashboard")
            self.end_headers()
            return

        # Other protected actions
        user = self.get_user()

        if not user:
            self.send_page("Unauthorized", 401)
            return

        if data.get("csrf", [""])[0] != user["csrf"]:
            self.send_page("CSRF Forbidden", 403)
            return

        # Create note
        if path == "/note":
            content = data.get("content", [""])[0]

            db = connect()
            db.execute(
                "INSERT INTO notes(owner_id, content) VALUES(?, ?)",
                (user["id"], content)
            )
            db.commit()
            db.close()

            self.send_response(303)
            self.send_header("Location", "/dashboard")
            self.end_headers()
            return

        # Logout
        if path == "/logout":
            cookies = SimpleCookie()
            cookies.load(self.headers.get("Cookie", ""))

            if "session" in cookies:
                token = cookies["session"].value
                token_hash = hashlib.sha256(token.encode()).hexdigest()

                db = connect()
                db.execute(
                    "DELETE FROM sessions WHERE token=?",
                    (token_hash,)
                )
                db.commit()
                db.close()

            self.send_response(303)
            self.send_header(
                "Set-Cookie",
                "session=; HttpOnly; Max-Age=0; Path=/"
            )
            self.send_header("Location", "/login")
            self.end_headers()
            return

        self.send_page("Not found", 404)


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("Commands: init, add-user, serve")

    elif sys.argv[1] == "init":
        init()

    elif sys.argv[1] == "add-user":
        username = input("Username: ")
        role = input("Role (student/teacher): ")
        password = getpass.getpass("Password: ")
        add_user(username, password, role)

    elif sys.argv[1] == "serve":
        print("AuthLab running at http://127.0.0.1:8000")
        server = HTTPServer(("127.0.0.1", 8000), AuthHandler)
        server.serve_forever()

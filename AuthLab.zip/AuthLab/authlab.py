import hashlib
import hmac
import getpass
import secrets
import sqlite3
import sys
from datetime import datetime, timedelta
from html import escape
from http.cookies import SimpleCookie
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

DB = "authlab.db"
PBKDF2_ITERATIONS = 600_000
IDLE_TIMEOUT_MINUTES = 20
ABSOLUTE_TIMEOUT_HOURS = 4
PRELOGIN_TIMEOUT_MINUTES = 10
MAX_LOGIN_ATTEMPTS = 5
LOGIN_BLOCK_MINUTES = 5


def connect():
    db = sqlite3.connect(DB)
    db.execute("PRAGMA foreign_keys = ON")
    return db


def init():
    db = connect()
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            salt TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student','teacher'))
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            csrf TEXT NOT NULL,
            created TEXT NOT NULL,
            last_activity TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS prelogins (
            token_hash TEXT PRIMARY KEY,
            csrf TEXT NOT NULL,
            created TEXT NOT NULL
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS login_attempts (
            username TEXT PRIMARY KEY,
            attempts INTEGER NOT NULL DEFAULT 0,
            blocked_until TEXT
        )
    """)
    db.commit()
    db.close()
    print("Database initialized")


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"),
        PBKDF2_ITERATIONS
    ).hex()


def verify_password(password, salt, expected_hash):
    actual = hash_password(password, salt)
    return hmac.compare_digest(actual, expected_hash)


def add_user(username, password, role):
    if role not in ("student", "teacher"):
        print("Invalid role")
        return
    salt = secrets.token_hex(16)
    hashed = hash_password(password, salt)
    db = connect()
    try:
        db.execute(
            "INSERT INTO users(username,password,salt,role) VALUES(?,?,?,?)",
            (username, hashed, salt, role)
        )
        db.commit()
        print("User created successfully")
    except sqlite3.IntegrityError:
        print("Username already exists")
    finally:
        db.close()


def token_hash(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def is_expired(created, now=None, minutes=PRELOGIN_TIMEOUT_MINUTES):
    now = now or datetime.now()
    created_at = datetime.fromisoformat(created) if isinstance(created, str) else created
    return now - created_at > timedelta(minutes=minutes)


def session_expired(created, last_activity, now=None):
    now = now or datetime.now()
    created_at = datetime.fromisoformat(created) if isinstance(created, str) else created
    last_at = datetime.fromisoformat(last_activity) if isinstance(last_activity, str) else last_activity
    return (
        now - created_at > timedelta(hours=ABSOLUTE_TIMEOUT_HOURS)
        or now - last_at > timedelta(minutes=IDLE_TIMEOUT_MINUTES)
    )


def cookie_header(name, value, max_age=None, secure=False, delete=False):
    cookie_name = "__Host-session" if secure and name == "session" else name
    parts = [f"{cookie_name}={value}", "HttpOnly", "SameSite=Lax", "Path=/"]
    if secure:
        parts.append("Secure")
    if max_age is not None:
        parts.append(f"Max-Age={max_age}")
    if delete:
        parts.append("Max-Age=0")
    return "; ".join(parts)


def create_prelogin():
    raw_token = secrets.token_urlsafe(32)
    csrf = secrets.token_urlsafe(32)
    return raw_token, token_hash(raw_token), csrf, datetime.now().isoformat()


def consume_prelogin(raw_token, csrf, now=None):
    if not raw_token or not csrf:
        return False
    db = connect()
    row = db.execute(
        "SELECT csrf, created FROM prelogins WHERE token_hash=?",
        (token_hash(raw_token),)
    ).fetchone()
    if row is None:
        db.close()
        return False
    db.execute("DELETE FROM prelogins WHERE token_hash=?", (token_hash(raw_token),))
    db.commit()
    db.close()
    if is_expired(row[1], now=now):
        return False
    return hmac.compare_digest(row[0], csrf)


def record_failed_login(username, now=None):
    now = now or datetime.now()
    blocked_until = (now + timedelta(minutes=LOGIN_BLOCK_MINUTES)).isoformat()
    db = connect()
    row = db.execute(
        "SELECT attempts, blocked_until FROM login_attempts WHERE username=?",
        (username,)
    ).fetchone()
    if row and row[1]:
        until = datetime.fromisoformat(row[1])
        if now < until:
            db.close()
            return MAX_LOGIN_ATTEMPTS, until
    attempts = (row[0] if row else 0) + 1
    if attempts >= MAX_LOGIN_ATTEMPTS:
        db.execute("""
            INSERT INTO login_attempts(username, attempts, blocked_until)
            VALUES(?,?,?)
            ON CONFLICT(username) DO UPDATE SET
                attempts=excluded.attempts,
                blocked_until=excluded.blocked_until
        """, (username, MAX_LOGIN_ATTEMPTS, blocked_until))
        db.commit()
        db.close()
        return MAX_LOGIN_ATTEMPTS, datetime.fromisoformat(blocked_until)
    db.execute("""
        INSERT INTO login_attempts(username, attempts, blocked_until)
        VALUES(?,?,NULL)
        ON CONFLICT(username) DO UPDATE SET
            attempts=excluded.attempts,
            blocked_until=NULL
    """, (username, attempts))
    db.commit()
    db.close()
    return attempts, None


def login_blocked(username, now=None):
    now = now or datetime.now()
    db = connect()
    row = db.execute(
        "SELECT blocked_until FROM login_attempts WHERE username=?",
        (username,)
    ).fetchone()
    db.close()
    if not row or not row[0]:
        return False
    return now < datetime.fromisoformat(row[0])


def clear_login_attempts(username):
    db = connect()
    db.execute("DELETE FROM login_attempts WHERE username=?", (username,))
    db.commit()
    db.close()


class AuthHandler(BaseHTTPRequestHandler):
    def send_page(self, content, status=200, cookie=None):
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Security-Policy", "default-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "same-origin")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(content.encode("utf-8"))

    def redirect(self, location):
        self.send_response(303)
        self.send_header("Location", location)
        self.end_headers()

    def read_cookies(self):
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get("Cookie", ""))
        except Exception:
            pass
        return cookies

    def get_user(self):
        cookies = self.read_cookies()
        cookie_name = "__Host-session" if self.is_https() else "session"
        if cookie_name not in cookies:
            return None
        raw_token = cookies[cookie_name].value
        db = connect()
        row = db.execute("""
            SELECT users.id, users.username, users.role,
                   sessions.csrf, sessions.created, sessions.last_activity,
                   sessions.token
            FROM sessions
            JOIN users ON users.id = sessions.user_id
            WHERE sessions.token = ?
        """, (token_hash(raw_token),)).fetchone()
        if not row:
            db.close()
            return None
        now = datetime.now()
        if session_expired(row[4], row[5], now):
            db.execute("DELETE FROM sessions WHERE token=?", (row[6],))
            db.commit()
            db.close()
            return None
        db.execute(
            "UPDATE sessions SET last_activity=? WHERE token=?",
            (now.isoformat(), row[6])
        )
        db.commit()
        db.close()
        return {"id": row[0], "username": row[1], "role": row[2], "csrf": row[3]}

    def is_https(self):
        # The supplied learning server runs on HTTP localhost.
        # Set this to True only when serving behind correctly configured HTTPS.
        return False

    def login_page(self, message=""):
        raw, hashed, csrf, created = create_prelogin()
        db = connect()
        db.execute(
            "INSERT OR REPLACE INTO prelogins(token_hash,csrf,created) VALUES(?,?,?)",
            (hashed, csrf, created)
        )
        db.commit()
        db.close()
        page = f"""
        <!doctype html><html><head><meta charset="utf-8"><title>AuthLab Login</title></head>
        <body><h2>AuthLab Login</h2>
        <p>{escape(message)}</p>
        <form method="POST" action="/login">
            <input type="hidden" name="csrf" value="{escape(csrf)}">
            <input name="username" placeholder="Username" autocomplete="username" required>
            <br><br>
            <input name="password" type="password" placeholder="Password" autocomplete="current-password" required>
            <br><br><button type="submit">Login</button>
        </form></body></html>
        """
        self.send_page(page, cookie=cookie_header("prelogin", raw, max_age=600))

    def do_GET(self):
        path = urlparse(self.path).path
        user = self.get_user()

        if path == "/":
            self.redirect("/dashboard" if user else "/login")
            return

        if path == "/login":
            self.login_page()
            return

        if not user:
            self.redirect("/login")
            return

        if path == "/dashboard":
            page = f"""
            <!doctype html><html><head><meta charset="utf-8"><title>Dashboard</title></head>
            <body><h2>Welcome, {escape(user['username'])}</h2>
            <p>Role: {escape(user['role'])}</p>
            <form method="POST" action="/note">
                <input type="hidden" name="csrf" value="{escape(user['csrf'])}">
                <input name="content" placeholder="Your note" maxlength="2000" required>
                <button type="submit">Create note</button>
            </form>
            <p><a href="/notes">My notes</a></p>
            <p><a href="/admin/users">Admin users</a></p>
            <form method="POST" action="/logout">
                <input type="hidden" name="csrf" value="{escape(user['csrf'])}">
                <button type="submit">Logout</button>
            </form></body></html>
            """
            self.send_page(page)
            return

        if path == "/notes":
            db = connect()
            rows = db.execute(
                "SELECT id, content FROM notes WHERE owner_id=? ORDER BY id",
                (user["id"],)
            ).fetchall()
            db.close()
            page = "<h2>My notes</h2>"
            for note_id, content in rows:
                page += (
                    f"<p><a href='/notes/{note_id}'>Note {note_id}</a>: "
                    f"{escape(content)}</p>"
                )
            self.send_page(page)
            return

        if path == "/admin/users":
            if user["role"] != "teacher":
                self.send_page("Forbidden", 403)
                return
            db = connect()
            rows = db.execute("SELECT username, role FROM users ORDER BY id").fetchall()
            db.close()
            page = "<h2>Users</h2>"
            for username, role in rows:
                page += f"<p>{escape(username)} - {escape(role)}</p>"
            self.send_page(page)
            return

        if path.startswith("/notes/"):
            try:
                note_id = int(path.rsplit("/", 1)[1])
            except ValueError:
                self.send_page("Not found", 404)
                return
            db = connect()
            note = db.execute(
                "SELECT content FROM notes WHERE id=? AND owner_id=?",
                (note_id, user["id"])
            ).fetchone()
            db.close()
            if note is None:
                self.send_page("Not found", 404)
            else:
                self.send_page(escape(note[0]))
            return

        self.send_page("Not found", 404)

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_page("Bad request", 400)
            return
        if length < 0 or length > 100_000:
            self.send_page("Bad request", 400)
            return
        raw_body = self.rfile.read(length).decode("utf-8", errors="replace")
        data = parse_qs(raw_body, keep_blank_values=True)
        path = urlparse(self.path).path

        if path == "/login":
            username = data.get("username", [""])[0].strip()
            password = data.get("password", [""])[0]
            csrf = data.get("csrf", [""])[0]
            cookies = self.read_cookies()
            prelogin_token = cookies["prelogin"].value if "prelogin" in cookies else ""
            if not consume_prelogin(prelogin_token, csrf):
                self.login_page("Login form expired or invalid. Please try again.")
                return
            if login_blocked(username):
                self.send_page("Too many failed attempts. Try again in 5 minutes.", 429)
                return

            db = connect()
            row = db.execute(
                "SELECT id, password, salt FROM users WHERE username=?",
                (username,)
            ).fetchone()
            db.close()

            if row is None or not verify_password(password, row[2], row[1]):
                record_failed_login(username)
                self.send_page("Invalid username or password", 401)
                return

            clear_login_attempts(username)
            raw_session = secrets.token_urlsafe(32)
            csrf_token = secrets.token_urlsafe(32)
            now = datetime.now().isoformat()
            db = connect()
            db.execute("""
                INSERT INTO sessions(token,user_id,csrf,created,last_activity)
                VALUES(?,?,?,?,?)
            """, (token_hash(raw_session), row[0], csrf_token, now, now))
            db.commit()
            db.close()
            self.send_response(303)
            self.send_header("Set-Cookie", cookie_header("session", raw_session, max_age=14400))
            self.send_header("Set-Cookie", cookie_header("prelogin", "", max_age=0, delete=True))
            self.send_header("Location", "/dashboard")
            self.end_headers()
            return

        user = self.get_user()
        if not user:
            self.send_page("Unauthorized", 401)
            return
        submitted_csrf = data.get("csrf", [""])[0]
        if not hmac.compare_digest(submitted_csrf, user["csrf"]):
            self.send_page("CSRF Forbidden", 403)
            return

        if path == "/note":
            content = data.get("content", [""])[0]
            if not content.strip() or len(content) > 2000:
                self.send_page("Invalid note", 400)
                return
            db = connect()
            db.execute(
                "INSERT INTO notes(owner_id,content) VALUES(?,?)",
                (user["id"], content)
            )
            db.commit()
            db.close()
            self.redirect("/dashboard")
            return

        if path == "/logout":
            cookies = self.read_cookies()
            cookie_name = "__Host-session" if self.is_https() else "session"
            if cookie_name in cookies:
                db = connect()
                db.execute(
                    "DELETE FROM sessions WHERE token=?",
                    (token_hash(cookies[cookie_name].value),)
                )
                db.commit()
                db.close()
            self.send_response(303)
            self.send_header("Set-Cookie", cookie_header("session", "", max_age=0, delete=True))
            self.send_header("Location", "/login")
            self.end_headers()
            return

        self.send_page("Not found", 404)


def serve():
    init()
    print("AuthLab running at http://127.0.0.1:8000")
    server = HTTPServer(("127.0.0.1", 8000), AuthHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped")
    finally:
        server.server_close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Commands: init, add-user, serve")
    elif sys.argv[1] == "init":
        init()
    elif sys.argv[1] == "add-user":
        username = input("Username: ").strip()
        role = input("Role (student/teacher): ").strip()
        password = getpass.getpass("Password: ")
        add_user(username, password, role)
    elif sys.argv[1] == "serve":
        serve()
    else:
        print("Unknown command")

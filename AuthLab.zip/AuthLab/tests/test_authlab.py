import os
import tempfile
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch

import authlab


class AuthLabTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = authlab.DB
        authlab.DB = os.path.join(self.temp.name, "test.db")
        self.iter_patch = patch.object(authlab, "PBKDF2_ITERATIONS", 2000)
        self.iter_patch.start()
        authlab.init()

    def tearDown(self):
        self.iter_patch.stop()
        authlab.DB = self.old_db
        self.temp.cleanup()

    def test_01_password_hash_returns_string(self):
        self.assertIsInstance(authlab.hash_password("pass", "salt"), str)

    def test_02_password_hash_is_sha256_length(self):
        self.assertEqual(len(authlab.hash_password("pass", "salt")), 64)

    def test_03_same_password_and_salt_same_hash(self):
        self.assertEqual(authlab.hash_password("abc", "salt"), authlab.hash_password("abc", "salt"))

    def test_04_different_password_different_hash(self):
        self.assertNotEqual(authlab.hash_password("abc", "salt"), authlab.hash_password("xyz", "salt"))

    def test_05_different_salt_different_hash(self):
        self.assertNotEqual(authlab.hash_password("abc", "salt1"), authlab.hash_password("abc", "salt2"))

    def test_06_password_verification_true(self):
        hashed = authlab.hash_password("secret", "salt")
        self.assertTrue(authlab.verify_password("secret", "salt", hashed))

    def test_07_password_verification_false(self):
        hashed = authlab.hash_password("secret", "salt")
        self.assertFalse(authlab.verify_password("wrong", "salt", hashed))

    def test_08_database_users_table(self):
        db = authlab.connect()
        row = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").fetchone()
        db.close()
        self.assertIsNotNone(row)

    def test_09_database_notes_table(self):
        db = authlab.connect()
        row = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='notes'").fetchone()
        db.close()
        self.assertIsNotNone(row)

    def test_10_database_sessions_table(self):
        db = authlab.connect()
        row = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sessions'").fetchone()
        db.close()
        self.assertIsNotNone(row)

    def test_11_database_prelogins_table(self):
        db = authlab.connect()
        row = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='prelogins'").fetchone()
        db.close()
        self.assertIsNotNone(row)

    def test_12_database_login_attempts_table(self):
        db = authlab.connect()
        row = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='login_attempts'").fetchone()
        db.close()
        self.assertIsNotNone(row)

    def test_13_prelogin_token_is_hashed(self):
        raw, hashed, csrf, created = authlab.create_prelogin()
        self.assertNotEqual(raw, hashed)
        self.assertEqual(len(hashed), 64)

    def test_14_prelogin_expiry_after_ten_minutes(self):
        old = datetime.now() - timedelta(minutes=11)
        self.assertTrue(authlab.is_expired(old))

    def test_15_session_idle_timeout(self):
        now = datetime.now()
        self.assertTrue(authlab.session_expired(now.isoformat(), (now - timedelta(minutes=21)).isoformat(), now))

    def test_16_session_absolute_timeout(self):
        now = datetime.now()
        self.assertTrue(authlab.session_expired((now - timedelta(hours=5)).isoformat(), now.isoformat(), now))

    def test_17_failed_login_blocks_after_five_attempts(self):
        for _ in range(4):
            attempts, blocked = authlab.record_failed_login("alice")
            self.assertIsNone(blocked)
        attempts, blocked = authlab.record_failed_login("alice")
        self.assertEqual(attempts, 5)
        self.assertIsNotNone(blocked)
        self.assertTrue(authlab.login_blocked("alice"))


if __name__ == "__main__":
    unittest.main()
